﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace GoudkoortV2
{
    public class ControlView
    {
        public void PrintControl()
        {
            Console.Clear();
            Console.WriteLine("-------------------");
            Console.WriteLine("the controlls for the rail switches are the numbers 1 - 5");
            Console.WriteLine("-------------------");
        }
        
    }
}