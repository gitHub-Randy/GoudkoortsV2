﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace GoudkoortV2
{
    public class ScoreView
    {
        public void PrintScore(int score)
        {
            Console.WriteLine("Score: "+score);
        }
    }
}