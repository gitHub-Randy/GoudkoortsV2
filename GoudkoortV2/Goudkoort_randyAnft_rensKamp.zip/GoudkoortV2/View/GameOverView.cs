﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace GoudkoortV2
{
    public class GameOverView
    {

        public void GameOverMessage()
        {
            
            Console.WriteLine("----------------------------------");
            Console.WriteLine("Jammer jij hebt verloren");
            Console.WriteLine("Druk op enter om af te sluiten");
            Console.WriteLine("----------------------------------");
        }
    }
}