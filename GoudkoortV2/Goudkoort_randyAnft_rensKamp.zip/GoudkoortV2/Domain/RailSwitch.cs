﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace GoudkoortV2
{
    public abstract  class RailSwitch : Rail
    {

        // Can have a wagon and can have diffrent states

        public abstract void Switch();
       
    }
}